# mb.miniAudioPlayer

__An open source jQuery component to build a mini audio player for your mp3 or ogg files.__

<b>jquery.mb.miniPlayer</b> is a GUI implementation of the <a href="http://www.happyworm.com/jquery/jplayer/" target="_blank">jquery.jPlayer</a> plug-in realized by © Happyworm LTD. (many thanks to <a href="http://happyworm.com/blog/" target="_blank">Mark Boas</a>)

![mb.menu](http://pupunzi.open-lab.com/wp-content/uploads/2011/05/DSC03757.jpg)

[jquery.mb.components](http://pupunzi.com/), another way of thinking the web
